import { create } from "zustand"
import { persist } from "zustand/middleware"

// ==================== Types ====================

export type ProjectStatus = "DRAFT" | "RESEARCHING" | "DRAFTING" | "REWRITING" | "PUBLISHING" | "COMPLETED" | "ARCHIVED"
export type TaskStatus = "PENDING" | "RUNNING" | "COMPLETED" | "FAILED" | "CANCELLED"
export type Platform = "WECHAT" | "XIAOHONGSHU" | "WEIBO" | "BILIBILI"
export type SearchTool = "WEB_SEARCH" | "NEWS_SEARCH" | "TAVILY"
export type PublishTarget = "WORDPRESS" | "EXPORT_MD" | "EXPORT_HTML" | "EXPORT_JSON" | "EXPORT_ZIP"
export type AssetStatus = "PENDING" | "GENERATING" | "COMPLETED" | "FAILED"

export interface Project {
  id: string
  title: string
  topicKeywords: string[]
  timeWindow: string
  status: ProjectStatus
  createdAt: string
  updatedAt: string
}

export interface ResearchTask {
  id: string
  projectId: string
  query: string
  tool: SearchTool
  status: TaskStatus
  progress: number
  error?: string
  startedAt?: string
  endedAt?: string
  createdAt: string
}

export interface SourceItem {
  id: string
  projectId: string
  url: string
  title: string
  publisher?: string
  publishedAt?: string
  snippet?: string
  contentExtracted?: string
  credibilityScore: number
  createdAt: string
}

export interface Insight {
  id: string
  projectId: string
  summary: string
  risks: string[]
  angles: string[]
  recommendedTitles: string[]
  createdAt: string
}

export interface DraftVersion {
  id: string
  projectId: string
  versionNo: number
  contentMd: string
  contentHtml?: string
  wordCount: number
  citations: string[]
  authorNote?: string
  isCurrent: boolean
  createdAt: string
}

export interface PlatformVariant {
  id: string
  draftId: string
  platform: Platform
  titleCandidates: string[]
  body: string
  hashtags: string[]
  coverCopy?: string
  createdAt: string
}

export interface AssetItem {
  id: string
  projectId: string
  prompt: string
  imageUrl?: string
  provider?: string
  status: AssetStatus
  linkedVariantIds: string[]
  createdAt: string
}

export interface PublishJob {
  id: string
  variantId?: string
  projectId: string
  target: PublishTarget
  payloadRef?: string
  status: TaskStatus
  retryCount: number
  lastError?: string
  remotePostId?: string
  createdAt: string
  updatedAt: string
}

export interface AnalyticsDaily {
  id: string
  date: string
  projectsCount: number
  draftsCount: number
  publishSuccessRate: number
  avgCycleMinutes: number
}

export interface Setting {
  id: string
  key: string
  value: string
  updatedAt: string
}

// ==================== Store State ====================

interface ContentPilotState {
  // Projects
  projects: Project[]
  currentProjectId: string | null
  addProject: (project: Omit<Project, "id" | "createdAt" | "updatedAt">) => string
  updateProject: (id: string, updates: Partial<Project>) => void
  deleteProject: (id: string) => void
  setCurrentProject: (id: string | null) => void
  
  // Research Tasks
  researchTasks: ResearchTask[]
  addResearchTask: (task: Omit<ResearchTask, "id" | "createdAt">) => string
  updateResearchTask: (id: string, updates: Partial<ResearchTask>) => void
  
  // Sources
  sources: SourceItem[]
  addSource: (source: Omit<SourceItem, "id" | "createdAt">) => string
  updateSource: (id: string, updates: Partial<SourceItem>) => void
  
  // Insights
  insights: Insight[]
  addInsight: (insight: Omit<Insight, "id" | "createdAt">) => string
  
  // Drafts
  drafts: DraftVersion[]
  addDraft: (draft: Omit<DraftVersion, "id" | "createdAt">) => string
  updateDraft: (id: string, updates: Partial<DraftVersion>) => void
  
  // Platform Variants
  variants: PlatformVariant[]
  addVariant: (variant: Omit<PlatformVariant, "id" | "createdAt">) => string
  updateVariant: (id: string, updates: Partial<PlatformVariant>) => void
  
  // Assets
  assets: AssetItem[]
  addAsset: (asset: Omit<AssetItem, "id" | "createdAt">) => string
  updateAsset: (id: string, updates: Partial<AssetItem>) => void
  
  // Publish Jobs
  publishJobs: PublishJob[]
  addPublishJob: (job: Omit<PublishJob, "id" | "createdAt" | "updatedAt">) => string
  updatePublishJob: (id: string, updates: Partial<PublishJob>) => void
  
  // Settings
  settings: Record<string, string>
  setSetting: (key: string, value: string) => void
  getSetting: (key: string, defaultValue?: string) => string | undefined
  
  // Analytics
  analytics: AnalyticsDaily[]
  addAnalytics: (data: Omit<AnalyticsDaily, "id">) => void
  
  // Utility
  clearAll: () => void
  exportData: () => string
  importData: (json: string) => boolean
}

// ==================== Helper Functions ====================

const generateId = () => `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
const now = () => new Date().toISOString()

// ==================== Store Implementation ====================

export const useStore = create<ContentPilotState>()(
  persist(
    (set, get) => ({
      // Projects
      projects: [],
      currentProjectId: null,
      
      addProject: (project) => {
        const id = generateId()
        const nowTime = now()
        set((state) => ({
          projects: [
            {
              ...project,
              id,
              createdAt: nowTime,
              updatedAt: nowTime,
            },
            ...state.projects,
          ],
        }))
        return id
      },
      
      updateProject: (id, updates) => {
        set((state) => ({
          projects: state.projects.map((p) =>
            p.id === id ? { ...p, ...updates, updatedAt: now() } : p
          ),
        }))
      },
      
      deleteProject: (id) => {
        set((state) => ({
          projects: state.projects.filter((p) => p.id !== id),
          currentProjectId: state.currentProjectId === id ? null : state.currentProjectId,
        }))
      },
      
      setCurrentProject: (id) => {
        set({ currentProjectId: id })
      },
      
      // Research Tasks
      researchTasks: [],
      
      addResearchTask: (task) => {
        const id = generateId()
        set((state) => ({
          researchTasks: [
            { ...task, id, createdAt: now() },
            ...state.researchTasks,
          ],
        }))
        return id
      },
      
      updateResearchTask: (id, updates) => {
        set((state) => ({
          researchTasks: state.researchTasks.map((t) =>
            t.id === id ? { ...t, ...updates } : t
          ),
        }))
      },
      
      // Sources
      sources: [],
      
      addSource: (source) => {
        const id = generateId()
        set((state) => ({
          sources: [
            { ...source, id, createdAt: now() },
            ...state.sources,
          ],
        }))
        return id
      },
      
      updateSource: (id, updates) => {
        set((state) => ({
          sources: state.sources.map((s) =>
            s.id === id ? { ...s, ...updates } : s
          ),
        }))
      },
      
      // Insights
      insights: [],
      
      addInsight: (insight) => {
        const id = generateId()
        set((state) => ({
          insights: [
            { ...insight, id, createdAt: now() },
            ...state.insights,
          ],
        }))
        return id
      },
      
      // Drafts
      drafts: [],
      
      addDraft: (draft) => {
        const id = generateId()
        set((state) => ({
          drafts: [
            { ...draft, id, createdAt: now() },
            ...state.drafts,
          ],
        }))
        return id
      },
      
      updateDraft: (id, updates) => {
        set((state) => ({
          drafts: state.drafts.map((d) =>
            d.id === id ? { ...d, ...updates } : d
          ),
        }))
      },
      
      // Variants
      variants: [],
      
      addVariant: (variant) => {
        const id = generateId()
        set((state) => ({
          variants: [
            { ...variant, id, createdAt: now() },
            ...state.variants,
          ],
        }))
        return id
      },
      
      updateVariant: (id, updates) => {
        set((state) => ({
          variants: state.variants.map((v) =>
            v.id === id ? { ...v, ...updates } : v
          ),
        }))
      },
      
      // Assets
      assets: [],
      
      addAsset: (asset) => {
        const id = generateId()
        set((state) => ({
          assets: [
            { ...asset, id, createdAt: now() },
            ...state.assets,
          ],
        }))
        return id
      },
      
      updateAsset: (id, updates) => {
        set((state) => ({
          assets: state.assets.map((a) =>
            a.id === id ? { ...a, ...updates } : a
          ),
        }))
      },
      
      // Publish Jobs
      publishJobs: [],
      
      addPublishJob: (job) => {
        const id = generateId()
        const nowTime = now()
        set((state) => ({
          publishJobs: [
            { ...job, id, createdAt: nowTime, updatedAt: nowTime },
            ...state.publishJobs,
          ],
        }))
        return id
      },
      
      updatePublishJob: (id, updates) => {
        set((state) => ({
          publishJobs: state.publishJobs.map((j) =>
            j.id === id ? { ...j, ...updates, updatedAt: now() } : j
          ),
        }))
      },
      
      // Settings
      settings: {},
      
      setSetting: (key, value) => {
        set((state) => ({
          settings: { ...state.settings, [key]: value },
        }))
      },
      
      getSetting: (key, defaultValue) => {
        return get().settings[key] ?? defaultValue
      },
      
      // Analytics
      analytics: [],
      
      addAnalytics: (data) => {
        const id = generateId()
        set((state) => ({
          analytics: [...state.analytics, { ...data, id }],
        }))
      },
      
      // Utility
      clearAll: () => {
        set({
          projects: [],
          currentProjectId: null,
          researchTasks: [],
          sources: [],
          insights: [],
          drafts: [],
          variants: [],
          assets: [],
          publishJobs: [],
          settings: {},
          analytics: [],
        })
      },
      
      exportData: () => {
        const state = get()
        return JSON.stringify({
          version: 1,
          exportedAt: now(),
          projects: state.projects,
          researchTasks: state.researchTasks,
          sources: state.sources,
          insights: state.insights,
          drafts: state.drafts,
          variants: state.variants,
          assets: state.assets,
          publishJobs: state.publishJobs,
          settings: state.settings,
          analytics: state.analytics,
        }, null, 2)
      },
      
      importData: (json) => {
        try {
          const data = JSON.parse(json)
          if (data.version !== 1) {
            console.error("Unsupported export version")
            return false
          }
          set({
            projects: data.projects || [],
            researchTasks: data.researchTasks || [],
            sources: data.sources || [],
            insights: data.insights || [],
            drafts: data.drafts || [],
            variants: data.variants || [],
            assets: data.assets || [],
            publishJobs: data.publishJobs || [],
            settings: data.settings || {},
            analytics: data.analytics || [],
          })
          return true
        } catch (e) {
          console.error("Failed to import data:", e)
          return false
        }
      },
    }),
    {
      name: "contentpilot-storage",
      version: 1,
    }
  )
)
