"use client"

import * as React from "react"
import { useSearchParams } from "next/navigation"
import {
  FileText,
  Save,
  Wand2,
  Clock,
  ChevronDown,
  Copy,
  Download,
  Loader2,
  Sparkles,
} from "lucide-react"
import { Header } from "@/components/layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Separator } from "@/components/ui/separator"
import { Progress } from "@/components/ui/progress"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible"
import { useStore, type DraftVersion } from "@/stores/project-store"
import { formatRelativeTime } from "@/lib/date"
import { cn } from "@/lib/utils"
import { toast } from "sonner"

// Tone options for draft generation
const toneOptions = [
  { value: "professional", label: "专业严谨" },
  { value: "casual", label: "轻松活泼" },
  { value: "storytelling", label: "故事叙述" },
  { value: "analytical", label: "分析解读" },
  { value: "tutorial", label: "教程指南" },
]

// Length options
const lengthOptions = [
  { value: "short", label: "短篇 (500-1000字)" },
  { value: "medium", label: "中篇 (1500-2500字)" },
  { value: "long", label: "长篇 (3000-5000字)" },
]

export default function DraftsPage() {
  const searchParams = useSearchParams()
  const projectId = searchParams.get("project")
  
  const {
    projects,
    currentProjectId,
    setCurrentProject,
    sources,
    insights,
    drafts,
    addDraft,
    updateDraft,
    updateProject,
  } = useStore()
  
  // Get current project
  const currentProject = projectId 
    ? projects.find(p => p.id === projectId)
    : currentProjectId 
      ? projects.find(p => p.id === currentProjectId)
      : null
  
  // Get project data
  const projectSources = currentProject 
    ? sources.filter(s => s.projectId === currentProject.id)
    : []
  const projectInsight = currentProject
    ? insights.find(i => i.projectId === currentProject.id)
    : null
  const projectDrafts = currentProject
    ? drafts.filter(d => d.projectId === currentProject.id)
    : []
  
  // Current draft
  const currentDraft = projectDrafts.find(d => d.isCurrent) || projectDrafts[0]
  
  // Form state
  const [content, setContent] = React.useState(currentDraft?.contentMd || "")
  const [tone, setTone] = React.useState("professional")
  const [length, setLength] = React.useState("medium")
  const [isGenerating, setIsGenerating] = React.useState(false)
  const [isSaving, setIsSaving] = React.useState(false)
  const [generateProgress, setGenerateProgress] = React.useState(0)
  
  // Word count
  const wordCount = content.length
  
  // Save draft
  const handleSave = async () => {
    if (!currentProject) {
      toast.error("请先创建或选择项目")
      return
    }
    
    setIsSaving(true)
    try {
      if (currentDraft) {
        updateDraft(currentDraft.id, {
          contentMd: content,
          wordCount,
        })
      } else {
        addDraft({
          projectId: currentProject.id,
          versionNo: 1,
          contentMd: content,
          wordCount,
          citations: [],
          isCurrent: true,
        })
      }
      toast.success("草稿已保存")
    } catch (error) {
      toast.error("保存失败")
    } finally {
      setIsSaving(false)
    }
  }
  
  // Generate draft
  const handleGenerate = async () => {
    if (!currentProject) {
      toast.error("请先进行选题研究")
      return
    }
    
    if (!projectInsight || projectSources.length === 0) {
      toast.error("研究资料不足，请先完成选题研究")
      return
    }
    
    setIsGenerating(true)
    setGenerateProgress(0)
    
    try {
      const response = await fetch("/api/draft/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          projectId: currentProject.id,
          tone,
          length,
        }),
      })
      
      if (!response.ok) {
        throw new Error("生成失败")
      }
      
      const reader = response.body?.getReader()
      if (!reader) throw new Error("无法读取响应")
      
      const decoder = new TextDecoder()
      let accumulatedContent = ""
      
      while (true) {
        const { done, value } = await reader.read()
        if (done) break
        
        const chunk = decoder.decode(value)
        const lines = chunk.split("\n").filter(Boolean)
        
        for (const line of lines) {
          try {
            const data = JSON.parse(line)
            
            if (data.type === "progress") {
              setGenerateProgress(data.progress)
            } else if (data.type === "content") {
              accumulatedContent += data.text
              setContent(accumulatedContent)
            }
          } catch (e) {
            // Ignore parse errors
          }
        }
      }
      
      // Save the generated draft
      const versionNo = projectDrafts.length + 1
      
      // Mark existing drafts as not current
      projectDrafts.forEach(d => {
        if (d.isCurrent) {
          updateDraft(d.id, { isCurrent: false })
        }
      })
      
      addDraft({
        projectId: currentProject.id,
        versionNo,
        contentMd: accumulatedContent,
        wordCount: accumulatedContent.length,
        citations: projectSources.slice(0, 5).map(s => s.url),
        isCurrent: true,
      })
      
      updateProject(currentProject.id, { status: "REWRITING" })
      toast.success("初稿生成完成！")
    } catch (error) {
      console.error("Generate error:", error)
      toast.error("生成失败，请重试")
    } finally {
      setIsGenerating(false)
    }
  }
  
  return (
    <div className="flex flex-col min-h-screen">
      <Header title="文章初稿">
        <div className="flex items-center gap-2">
          <Button 
            variant="outline" 
            size="sm"
            onClick={handleSave}
            disabled={isSaving || !content}
          >
            {isSaving ? (
              <Loader2 className="size-4 mr-1 animate-spin" />
            ) : (
              <Save className="size-4 mr-1" />
            )}
            保存
          </Button>
          <Button 
            size="sm"
            onClick={handleGenerate}
            disabled={isGenerating || !currentProject}
          >
            {isGenerating ? (
              <Loader2 className="size-4 mr-1 animate-spin" />
            ) : (
              <Wand2 className="size-4 mr-1" />
            )}
            生成初稿
          </Button>
        </div>
      </Header>
      
      <main className="flex-1 p-6">
        <div className="grid gap-6 lg:grid-cols-4">
          {/* Left: Editor */}
          <div className="lg:col-span-3 space-y-4">
            {/* Toolbar */}
            <Card>
              <CardContent className="py-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2">
                      <Label className="text-sm">风格</Label>
                      <Select value={tone} onValueChange={setTone} disabled={isGenerating}>
                        <SelectTrigger className="w-32">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {toneOptions.map((opt) => (
                            <SelectItem key={opt.value} value={opt.value}>
                              {opt.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <Label className="text-sm">篇幅</Label>
                      <Select value={length} onValueChange={setLength} disabled={isGenerating}>
                        <SelectTrigger className="w-40">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {lengthOptions.map((opt) => (
                            <SelectItem key={opt.value} value={opt.value}>
                              {opt.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3 text-sm text-muted-foreground">
                    <span className="tabular-nums">{wordCount} 字</span>
                    {currentDraft && (
                      <Badge variant="secondary">
                        v{currentDraft.versionNo}
                      </Badge>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Progress Bar */}
            {isGenerating && (
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">正在生成...</span>
                  <span className="tabular-nums">{generateProgress}%</span>
                </div>
                <Progress value={generateProgress} />
              </div>
            )}
            
            {/* Editor */}
            <Card className="flex-1">
              <CardContent className="p-0">
                <Textarea
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="在此编写或生成初稿..."
                  className="min-h-[500px] border-0 rounded-none resize-none focus-visible:ring-0 p-4 text-sm leading-relaxed"
                  disabled={isGenerating}
                />
              </CardContent>
            </Card>
            
            {/* Citations */}
            {projectSources.length > 0 && (
              <Collapsible>
                <CollapsibleTrigger className="flex items-center gap-2 text-sm font-medium hover:text-foreground transition-colors">
                  <ChevronDown className="size-4" />
                  引用来源 ({projectSources.length})
                </CollapsibleTrigger>
                <CollapsibleContent className="mt-2">
                  <div className="flex flex-wrap gap-2">
                    {projectSources.slice(0, 8).map((source, i) => (
                      <a
                        key={source.id}
                        href={source.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-xs bg-muted px-2 py-1 rounded hover:bg-muted/80 transition-colors"
                      >
                        [{i + 1}] {source.publisher || new URL(source.url).hostname}
                      </a>
                    ))}
                  </div>
                </CollapsibleContent>
              </Collapsible>
            )}
          </div>
          
          {/* Right: Sidebar */}
          <div className="space-y-4">
            {/* Project Info */}
            {currentProject && (
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm">当前项目</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <p className="font-medium text-sm">{currentProject.title}</p>
                  <div className="flex flex-wrap gap-1">
                    {currentProject.topicKeywords.map((keyword) => (
                      <Badge key={keyword} variant="secondary" className="text-xs">
                        {keyword}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
            
            {/* Insight Summary */}
            {projectInsight && (
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <Sparkles className="size-4" />
                    研究结论
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground line-clamp-4">
                    {projectInsight.summary}
                  </p>
                  {projectInsight.recommendedTitles.length > 0 && (
                    <div className="mt-3 space-y-1">
                      <p className="text-xs font-medium">推荐标题:</p>
                      <p className="text-xs text-muted-foreground">
                        {projectInsight.recommendedTitles[0]}
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}
            
            {/* Version History */}
            {projectDrafts.length > 0 && (
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm">版本历史</CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-[150px]">
                    <div className="space-y-2">
                      {projectDrafts.map((draft) => (
                        <div
                          key={draft.id}
                          className={cn(
                            "p-2 rounded text-sm cursor-pointer hover:bg-muted/50 transition-colors",
                            draft.isCurrent && "bg-muted"
                          )}
                        >
                          <div className="flex items-center justify-between">
                            <span className="font-medium">v{draft.versionNo}</span>
                            <span className="text-xs text-muted-foreground">
                              {formatRelativeTime(draft.createdAt)}
                            </span>
                          </div>
                          <p className="text-xs text-muted-foreground mt-1">
                            {draft.wordCount} 字
                          </p>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            )}
            
            {/* Quick Tips */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm">写作提示</CardTitle>
              </CardHeader>
              <CardContent className="text-xs text-muted-foreground space-y-2">
                <p>• 选择合适的风格让内容更贴近目标受众</p>
                <p>• 生成后可直接编辑修改</p>
                <p>• 每次保存会创建新版本</p>
                <p>• 引用来源会自动标注在文末</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}
