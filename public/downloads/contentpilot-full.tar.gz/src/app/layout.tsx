import type { Metadata } from "next"
import { Inter, JetBrains_Mono } from "next/font/google"
import "./globals.css"
import { Toaster } from "@/components/ui/sonner"
import { Providers } from "@/components/providers"
import { SidebarProvider, SidebarInset } from "@/components/ui/sidebar"
import { AppSidebar } from "@/components/layout/app-sidebar"

const inter = Inter({
  variable: "--font-geist-sans",
  subsets: ["latin"],
})

const jetbrainsMono = JetBrains_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
})

export const metadata: Metadata = {
  title: "ContentPilot - 内容生产流水线助手",
  description: "为媒体/自媒体小团队设计的内容生产流水线助手，把选题、研究、写作、改写、发布变成可追踪的任务流。",
  keywords: ["ContentPilot", "内容创作", "自媒体", "AI写作", "多平台发布"],
  authors: [{ name: "ContentPilot Team" }],
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="zh-CN" suppressHydrationWarning>
      <body
        className={`${inter.variable} ${jetbrainsMono.variable} font-sans antialiased`}
      >
        <Providers>
          <SidebarProvider>
            <AppSidebar />
            <SidebarInset className="flex flex-col min-h-screen">
              {children}
            </SidebarInset>
          </SidebarProvider>
          <Toaster position="top-right" />
        </Providers>
      </body>
    </html>
  )
}
