"use client"

import * as React from "react"
import {
  Settings,
  Key,
  Zap,
  FileText,
  Download,
  Upload,
  Trash2,
  Save,
  Eye,
  EyeOff,
  Check,
} from "lucide-react"
import { Header } from "@/components/layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Separator } from "@/components/ui/separator"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useStore } from "@/stores/project-store"
import { toast } from "sonner"

export default function SettingsPage() {
  const { settings, setSetting, clearAll, exportData, importData } = useStore()
  
  // Form state
  const [apiKey, setApiKey] = React.useState(settings.OPENAI_API_KEY || "")
  const [apiEndpoint, setApiEndpoint] = React.useState(settings.OPENAI_ENDPOINT || "https://api.openai.com/v1")
  const [modelName, setModelName] = React.useState(settings.MODEL_NAME || "gpt-4o-mini")
  const [showApiKey, setShowApiKey] = React.useState(false)
  
  // Platform templates
  const [wechatTemplate, setWechatTemplate] = React.useState(settings.WECHAT_TEMPLATE || "")
  const [xhsTemplate, setXhsTemplate] = React.useState(settings.XHS_TEMPLATE || "")
  
  // Save settings
  const handleSaveApiSettings = () => {
    setSetting("OPENAI_API_KEY", apiKey)
    setSetting("OPENAI_ENDPOINT", apiEndpoint)
    setSetting("MODEL_NAME", modelName)
    toast.success("设置已保存")
  }
  
  // Save platform templates
  const handleSaveTemplates = () => {
    setSetting("WECHAT_TEMPLATE", wechatTemplate)
    setSetting("XHS_TEMPLATE", xhsTemplate)
    toast.success("模板已保存")
  }
  
  // Export data
  const handleExport = () => {
    const data = exportData()
    const blob = new Blob([data], { type: "application/json" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `contentpilot-backup-${Date.now()}.json`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
    toast.success("数据已导出")
  }
  
  // Import data
  const handleImport = () => {
    const input = document.createElement("input")
    input.type = "file"
    input.accept = ".json"
    input.onchange = async (e) => {
      const file = (e.target as HTMLInputElement).files?.[0]
      if (!file) return
      
      const reader = new FileReader()
      reader.onload = (event) => {
        const content = event.target?.result as string
        if (importData(content)) {
          toast.success("数据已导入")
        } else {
          toast.error("导入失败，文件格式不正确")
        }
      }
      reader.readAsText(file)
    }
    input.click()
  }
  
  // Clear all data
  const handleClearAll = () => {
    if (confirm("确定要清除所有数据吗？此操作不可恢复。")) {
      clearAll()
      toast.success("数据已清除")
    }
  }
  
  // Common models
  const commonModels = [
    { value: "gpt-4o-mini", label: "GPT-4o Mini (推荐)" },
    { value: "gpt-4o", label: "GPT-4o" },
    { value: "gpt-4-turbo", label: "GPT-4 Turbo" },
    { value: "gpt-3.5-turbo", label: "GPT-3.5 Turbo" },
    { value: "glm-4-flash", label: "GLM-4 Flash" },
    { value: "glm-4-plus", label: "GLM-4 Plus" },
  ]
  
  return (
    <div className="flex flex-col min-h-screen">
      <Header title="设置" />
      
      <main className="flex-1 p-6">
        <Tabs defaultValue="api" className="space-y-6">
          <TabsList className="grid w-full max-w-md grid-cols-4">
            <TabsTrigger value="api">API</TabsTrigger>
            <TabsTrigger value="model">模型</TabsTrigger>
            <TabsTrigger value="templates">模板</TabsTrigger>
            <TabsTrigger value="data">数据</TabsTrigger>
          </TabsList>
          
          {/* API Settings */}
          <TabsContent value="api" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Key className="size-4" />
                  API 配置
                </CardTitle>
                <CardDescription>
                  配置 OpenAI 兼容接口的 API Key 和端点
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="apiKey">API Key</Label>
                  <div className="relative">
                    <Input
                      id="apiKey"
                      type={showApiKey ? "text" : "password"}
                      value={apiKey}
                      onChange={(e) => setApiKey(e.target.value)}
                      placeholder="sk-..."
                      className="pr-10"
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      className="absolute right-0 top-0"
                      onClick={() => setShowApiKey(!showApiKey)}
                    >
                      {showApiKey ? (
                        <EyeOff className="size-4" />
                      ) : (
                        <Eye className="size-4" />
                      )}
                    </Button>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="endpoint">API 端点</Label>
                  <Input
                    id="endpoint"
                    value={apiEndpoint}
                    onChange={(e) => setApiEndpoint(e.target.value)}
                    placeholder="https://api.openai.com/v1"
                  />
                  <p className="text-xs text-muted-foreground">
                    支持 OpenAI 兼容接口（如 GLM、DeepSeek 等）
                  </p>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="model">默认模型</Label>
                  <Select value={modelName} onValueChange={setModelName}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {commonModels.map((model) => (
                        <SelectItem key={model.value} value={model.value}>
                          {model.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <Separator />
                
                <Button onClick={handleSaveApiSettings}>
                  <Save className="size-4 mr-2" />
                  保存设置
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Model Settings */}
          <TabsContent value="model" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Zap className="size-4" />
                  模型参数
                </CardTitle>
                <CardDescription>
                  调整生成内容时的模型参数
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label>Temperature</Label>
                    <Select defaultValue="0.7">
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="0.3">0.3 (严谨)</SelectItem>
                        <SelectItem value="0.5">0.5 (平衡)</SelectItem>
                        <SelectItem value="0.7">0.7 (创意)</SelectItem>
                        <SelectItem value="0.9">0.9 (发散)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Max Tokens</Label>
                    <Select defaultValue="4096">
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="2048">2048</SelectItem>
                        <SelectItem value="4096">4096</SelectItem>
                        <SelectItem value="8192">8192</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>自动降级</Label>
                    <p className="text-xs text-muted-foreground">
                      当大模型超时时自动切换到小模型
                    </p>
                  </div>
                  <Switch defaultChecked />
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>流式输出</Label>
                    <p className="text-xs text-muted-foreground">
                      生成内容时实时显示进度
                    </p>
                  </div>
                  <Switch defaultChecked />
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Platform Templates */}
          <TabsContent value="templates" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <FileText className="size-4" />
                  平台模板规则
                </CardTitle>
                <CardDescription>
                  自定义各平台的内容改写规则
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>公众号模板</Label>
                  <Textarea
                    value={wechatTemplate}
                    onChange={(e) => setWechatTemplate(e.target.value)}
                    placeholder="输入公众号文章的改写规则..."
                    rows={4}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label>小红书模板</Label>
                  <Textarea
                    value={xhsTemplate}
                    onChange={(e) => setXhsTemplate(e.target.value)}
                    placeholder="输入小红书笔记的改写规则..."
                    rows={4}
                  />
                </div>
                
                <Separator />
                
                <Button onClick={handleSaveTemplates}>
                  <Save className="size-4 mr-2" />
                  保存模板
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Data Management */}
          <TabsContent value="data" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">数据管理</CardTitle>
                <CardDescription>
                  导入、导出或清除数据
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-4">
                  <Button variant="outline" onClick={handleExport}>
                    <Download className="size-4 mr-2" />
                    导出数据
                  </Button>
                  <Button variant="outline" onClick={handleImport}>
                    <Upload className="size-4 mr-2" />
                    导入数据
                  </Button>
                </div>
                
                <Separator />
                
                <div className="space-y-2">
                  <p className="text-sm font-medium text-destructive">危险操作</p>
                  <p className="text-xs text-muted-foreground">
                    清除所有本地存储的数据，包括项目、草稿、素材等。此操作不可恢复。
                  </p>
                  <Button variant="destructive" onClick={handleClearAll}>
                    <Trash2 className="size-4 mr-2" />
                    清除所有数据
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
