"use client"

import * as React from "react"
import {
  BarChart3,
  TrendingUp,
  TrendingDown,
  Clock,
  FileText,
  CheckCircle2,
  Send,
} from "lucide-react"
import { Header } from "@/components/layout"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { StatCard } from "@/components/cards"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"
import { useStore } from "@/stores/project-store"
import { formatDuration } from "@/lib/date"
import { getPlatformConfig } from "@/lib/platforms"

// Mock data for charts
const weeklyData = [
  { day: "周一", 产出: 2, 发布: 1 },
  { day: "周二", 产出: 3, 发布: 2 },
  { day: "周三", 产出: 1, 发布: 1 },
  { day: "周四", 产出: 4, 发布: 3 },
  { day: "周五", 产出: 2, 发布: 2 },
  { day: "周六", 产出: 1, 发布: 1 },
  { day: "周日", 产出: 0, 发布: 0 },
]

const platformData = [
  { name: "公众号", value: 35, platform: "WECHAT" },
  { name: "小红书", value: 28, platform: "XIAOHONGSHU" },
  { name: "微博", value: 22, platform: "WEIBO" },
  { name: "B站", value: 15, platform: "BILIBILI" },
]

const COLORS = ["oklch(0.5 0.15 145)", "oklch(0.65 0.18 15)", "oklch(0.6 0.18 25)", "oklch(0.55 0.2 260)"]

export default function AnalyticsPage() {
  const { projects, drafts, publishJobs, analytics } = useStore()
  
  const [timeRange, setTimeRange] = React.useState("7d")
  
  // Calculate stats
  const completedProjects = projects.filter(p => p.status === "COMPLETED").length
  const totalDrafts = drafts.length
  const successfulPublishes = publishJobs.filter(j => j.status === "COMPLETED").length
  const failedPublishes = publishJobs.filter(j => j.status === "FAILED").length
  const successRate = publishJobs.length > 0 
    ? Math.round((successfulPublishes / publishJobs.length) * 100) 
    : 0
  
  // Mock stats for display
  const stats = {
    weeklyOutput: completedProjects,
    avgCycleTime: 28,
    successRate,
    growthRate: 32,
  }
  
  return (
    <div className="flex flex-col min-h-screen">
      <Header title="数据统计">
        <Select value={timeRange} onValueChange={setTimeRange}>
          <SelectTrigger className="w-32">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="7d">最近7天</SelectItem>
            <SelectItem value="30d">最近30天</SelectItem>
            <SelectItem value="90d">最近90天</SelectItem>
          </SelectContent>
        </Select>
      </Header>
      
      <main className="flex-1 p-6 space-y-6">
        {/* Stats Grid */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <StatCard
            title="本周产出"
            value={stats.weeklyOutput}
            description="篇内容"
            icon={FileText}
            trend={{ value: stats.growthRate, isPositive: true }}
          />
          <StatCard
            title="平均周期"
            value={formatDuration(stats.avgCycleTime)}
            description="选题到发布"
            icon={Clock}
          />
          <StatCard
            title="发布成功率"
            value={`${stats.successRate}%`}
            description={`${successfulPublishes}/${publishJobs.length} 次`}
            icon={CheckCircle2}
          />
          <StatCard
            title="总发布次数"
            value={publishJobs.length}
            description={`失败 ${failedPublishes} 次`}
            icon={Send}
          />
        </div>
        
        {/* Charts */}
        <div className="grid gap-6 lg:grid-cols-2">
          {/* Weekly Output Chart */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">每日产出</CardTitle>
              <CardDescription>本周内容产出趋势</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={weeklyData}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis dataKey="day" className="text-xs" />
                    <YAxis className="text-xs" />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: "var(--card)", 
                        border: "1px solid var(--border)",
                        borderRadius: "8px"
                      }}
                    />
                    <Bar dataKey="产出" fill="var(--primary)" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="发布" fill="var(--success)" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
          
          {/* Platform Distribution */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">平台分布</CardTitle>
              <CardDescription>内容在各平台的发布比例</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px] flex items-center justify-center">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={platformData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={100}
                      paddingAngle={2}
                      dataKey="value"
                    >
                      {platformData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              
              {/* Legend */}
              <div className="flex justify-center gap-4 mt-4">
                {platformData.map((entry, index) => (
                  <div key={entry.name} className="flex items-center gap-2">
                    <div 
                      className="size-3 rounded-full"
                      style={{ backgroundColor: COLORS[index] }}
                    />
                    <span className="text-sm text-muted-foreground">
                      {entry.name} {entry.value}%
                    </span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* Key Metrics */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">核心指标达成</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-6 md:grid-cols-4">
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">选题到初稿</span>
                  <span className="font-medium">28 分钟</span>
                </div>
                <Progress value={93} className="h-2" />
                <p className="text-xs text-muted-foreground">目标: &lt; 30 分钟</p>
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">多平台改写</span>
                  <span className="font-medium">8 分钟</span>
                </div>
                <Progress value={100} className="h-2" />
                <p className="text-xs text-muted-foreground">目标: &lt; 10 分钟</p>
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">导出成功率</span>
                  <span className="font-medium">99%</span>
                </div>
                <Progress value={99} className="h-2" />
                <p className="text-xs text-muted-foreground">目标: &gt; 98%</p>
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">产出提升</span>
                  <span className="font-medium">+35%</span>
                </div>
                <Progress value={100} className="h-2" />
                <p className="text-xs text-muted-foreground">目标: ≥ 30%</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
