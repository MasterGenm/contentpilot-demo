"use client"

import * as React from "react"
import { Plus, FileText, Clock, CheckCircle2, AlertTriangle, TrendingUp } from "lucide-react"
import { Header } from "@/components/layout"
import { Button } from "@/components/ui/button"
import { StatCard, StatusBadge, ProjectCard } from "@/components/cards"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ScrollArea } from "@/components/ui/scroll-area"
import { useStore, type Project } from "@/stores/project-store"
import { formatRelativeTime, formatDuration } from "@/lib/date"

export default function DashboardPage() {
  const { projects, researchTasks, drafts, publishJobs } = useStore()
  
  // Calculate stats
  const activeProjects = projects.filter(p => 
    !["COMPLETED", "ARCHIVED"].includes(p.status)
  )
  const completedThisWeek = projects.filter(p => {
    const updated = new Date(p.updatedAt)
    const weekAgo = new Date()
    weekAgo.setDate(weekAgo.getDate() - 7)
    return p.status === "COMPLETED" && updated > weekAgo
  })
  const failedTasks = [...researchTasks, ...publishJobs].filter(t => t.status === "FAILED")
  const pendingTasks = researchTasks.filter(t => t.status === "PENDING" || t.status === "RUNNING")
  
  // Recent projects (last 5)
  const recentProjects = projects.slice(0, 5)
  
  // Mock weekly stats for display
  const weeklyStats = {
    avgCycleTime: 28, // minutes
    successRate: 96,
    outputGrowth: 32,
  }

  return (
    <div className="flex flex-col min-h-screen">
      <Header title="工作台">
        <Button size="sm">
          <Plus className="size-4 mr-1" />
          新建项目
        </Button>
      </Header>
      
      <main className="flex-1 p-6 space-y-6">
        {/* Stats Grid */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <StatCard
            title="活跃项目"
            value={activeProjects.length}
            description="进行中"
            icon={FileText}
          />
          <StatCard
            title="本周产出"
            value={completedThisWeek.length}
            description="篇内容"
            icon={CheckCircle2}
            trend={{ value: weeklyStats.outputGrowth, isPositive: true }}
          />
          <StatCard
            title="平均周期"
            value={formatDuration(weeklyStats.avgCycleTime)}
            description="选题到发布"
            icon={Clock}
          />
          <StatCard
            title="失败任务"
            value={failedTasks.length}
            description={failedTasks.length > 0 ? "需要处理" : "运行正常"}
            icon={failedTasks.length > 0 ? AlertTriangle : CheckCircle2}
            className={failedTasks.length > 0 ? "border-destructive/50" : ""}
          />
        </div>
        
        {/* Main Content */}
        <div className="grid gap-6 lg:grid-cols-3">
          {/* Recent Projects */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-base">最近项目</CardTitle>
                  <Button variant="ghost" size="sm" className="text-muted-foreground">
                    查看全部
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {recentProjects.length > 0 ? (
                  <div className="grid gap-4 md:grid-cols-2">
                    {recentProjects.map((project) => (
                      <ProjectCard key={project.id} project={project} />
                    ))}
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center py-12 text-center">
                    <FileText className="size-12 text-muted-foreground/50 mb-4" />
                    <p className="text-muted-foreground mb-4">还没有项目</p>
                    <Button>
                      <Plus className="size-4 mr-1" />
                      创建第一个项目
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
          
          {/* Sidebar */}
          <div className="space-y-6">
            {/* Pending Tasks */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">进行中的任务</CardTitle>
              </CardHeader>
              <CardContent>
                {pendingTasks.length > 0 ? (
                  <ScrollArea className="h-[200px]">
                    <div className="space-y-3">
                      {pendingTasks.slice(0, 5).map((task) => (
                        <div key={task.id} className="flex items-start gap-3 p-2 rounded-lg hover:bg-muted/50 transition-colors">
                          <div className="size-2 rounded-full bg-primary mt-2 animate-pulse" />
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium truncate">{task.query || "研究任务"}</p>
                            <p className="text-xs text-muted-foreground">
                              {formatRelativeTime(task.createdAt)}
                            </p>
                          </div>
                          <StatusBadge status={task.status} />
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                ) : (
                  <div className="text-center py-8 text-muted-foreground text-sm">
                    没有进行中的任务
                  </div>
                )}
              </CardContent>
            </Card>
            
            {/* Failed Tasks Alert */}
            {failedTasks.length > 0 && (
              <Card className="border-destructive/50">
                <CardHeader className="pb-3">
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="size-4 text-destructive" />
                    <CardTitle className="text-base text-destructive">失败任务告警</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-[150px]">
                    <div className="space-y-2">
                      {failedTasks.slice(0, 3).map((task) => (
                        <div key={task.id} className="p-2 rounded bg-destructive/10 text-sm">
                          <p className="font-medium truncate">{task.error || "任务失败"}</p>
                          <p className="text-xs text-muted-foreground mt-1">
                            {formatRelativeTime("createdAt" in task ? task.createdAt : task.updatedAt)}
                          </p>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                  <Button variant="destructive" size="sm" className="w-full mt-3">
                    重试失败任务
                  </Button>
                </CardContent>
              </Card>
            )}
            
            {/* Quick Stats */}
            <Card>
              <CardHeader className="pb-3">
                <div className="flex items-center gap-2">
                  <TrendingUp className="size-4 text-success" />
                  <CardTitle className="text-base">本周表现</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">发布成功率</span>
                    <span className="text-sm font-medium tabular-nums">{weeklyStats.successRate}%</span>
                  </div>
                  <div className="h-2 bg-muted rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-success rounded-full transition-all"
                      style={{ width: `${weeklyStats.successRate}%` }}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4 pt-2">
                    <div className="text-center p-2 bg-muted/50 rounded">
                      <p className="text-lg font-bold tabular-nums">{drafts.length}</p>
                      <p className="text-xs text-muted-foreground">草稿</p>
                    </div>
                    <div className="text-center p-2 bg-muted/50 rounded">
                      <p className="text-lg font-bold tabular-nums">{projects.length}</p>
                      <p className="text-xs text-muted-foreground">总项目</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
      
      <footer className="border-t py-4 px-6 text-center text-xs text-muted-foreground">
        ContentPilot © {new Date().getFullYear()} - 内容生产流水线助手
      </footer>
    </div>
  )
}
