import { NextRequest, NextResponse } from "next/server"

export const runtime = "nodejs"
export const dynamic = "force-dynamic"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { projectId, variantId, format } = body
    
    // Generate export content
    // For MVP, we'll return a simple text file
    
    let content = ""
    let filename = "export"
    let mimeType = "text/plain"
    
    switch (format) {
      case "EXPORT_MD":
        content = `# ContentPilot 导出\n\n导出时间: ${new Date().toISOString()}\n\n---\n\n内容将在这里显示...`
        filename = `contentpilot-${Date.now()}.md`
        mimeType = "text/markdown"
        break
        
      case "EXPORT_HTML":
        content = `<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ContentPilot 导出</title>
  <style>
    body { font-family: system-ui, sans-serif; max-width: 800px; margin: 0 auto; padding: 2rem; }
  </style>
</head>
<body>
  <h1>ContentPilot 导出</h1>
  <p>导出时间: ${new Date().toISOString()}</p>
  <hr>
  <div id="content">
    <p>内容将在这里显示...</p>
  </div>
</body>
</html>`
        filename = `contentpilot-${Date.now()}.html`
        mimeType = "text/html"
        break
        
      case "EXPORT_JSON":
        content = JSON.stringify({
          version: 1,
          exportedAt: new Date().toISOString(),
          projectId,
          variantId,
          content: "内容将在这里显示...",
        }, null, 2)
        filename = `contentpilot-${Date.now()}.json`
        mimeType = "application/json"
        break
        
      case "EXPORT_ZIP":
        // For ZIP, we'd normally use a library like JSZip
        // For MVP, return JSON with all data
        content = JSON.stringify({
          version: 1,
          exportedAt: new Date().toISOString(),
          format: "zip-placeholder",
          files: [],
        }, null, 2)
        filename = `contentpilot-${Date.now()}.json`
        mimeType = "application/json"
        break
        
      default:
        return NextResponse.json(
          { error: "Invalid export format" },
          { status: 400 }
        )
    }
    
    // Return as downloadable file
    return new Response(content, {
      headers: {
        "Content-Type": mimeType,
        "Content-Disposition": `attachment; filename="${filename}"`,
      },
    })
  } catch (error) {
    console.error("Export error:", error)
    return NextResponse.json(
      {
        error: {
          code: "INTERNAL_ERROR",
          message: "导出失败",
          detail: error instanceof Error ? error.message : undefined,
          retryable: true,
        },
      },
      { status: 500 }
    )
  }
}
