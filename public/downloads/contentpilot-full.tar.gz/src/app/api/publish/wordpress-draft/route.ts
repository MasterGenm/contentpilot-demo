import { NextRequest, NextResponse } from "next/server"

export const runtime = "nodejs"
export const dynamic = "force-dynamic"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { variantId, site, authRef } = body
    
    if (!variantId) {
      return NextResponse.json(
        { error: "Variant ID is required" },
        { status: 400 }
      )
    }
    
    // For MVP, we simulate a WordPress API call
    // In production, this would use the actual WordPress REST API
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000))
    
    // Generate a mock post ID
    const mockPostId = Math.floor(Math.random() * 100000)
    
    // In a real implementation:
    // 1. Get variant content from database
    // 2. Get WordPress credentials from settings
    // 3. Call WordPress REST API to create draft
    // 4. Return the post ID and edit URL
    
    return NextResponse.json({
      success: true,
      postId: mockPostId,
      editUrl: `https://example.com/wp-admin/post.php?post=${mockPostId}&action=edit`,
      message: "已推送至 WordPress 草稿",
    })
  } catch (error) {
    console.error("WordPress publish error:", error)
    return NextResponse.json(
      {
        error: {
          code: "PUBLISH_AUTH_FAILED",
          message: "WordPress 发布失败",
          detail: error instanceof Error ? error.message : undefined,
          retryable: true,
        },
      },
      { status: 500 }
    )
  }
}
