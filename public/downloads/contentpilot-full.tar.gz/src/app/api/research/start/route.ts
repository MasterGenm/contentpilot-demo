import { NextRequest } from "next/server"
import ZAI from "z-ai-web-dev-sdk"

export const runtime = "nodejs"
export const dynamic = "force-dynamic"

interface SearchSource {
  url: string
  title: string
  publisher?: string
  snippet?: string
  publishedAt?: string
  credibilityScore: number
}

interface ResearchInsight {
  summary: string
  risks: string[]
  angles: string[]
  recommendedTitles: string[]
}

// Credibility scoring based on domain
function getCredibilityScore(hostname: string): number {
  const highCredibilityDomains = [
    "reuters.com", "apnews.com", "bbc.com", "nytimes.com", 
    "wsj.com", "ft.com", "economist.com", "nature.com",
    "science.org", "pnas.org", "ieee.org", "acm.org",
    "gov.cn", "gov.uk", "gov", "edu.cn", "edu"
  ]
  
  const mediumCredibilityDomains = [
    "cnbc.com", "bloomberg.com", "forbes.com", "techcrunch.com",
    "theverge.com", "wired.com", "medium.com", "substack.com",
    "zhihu.com", "36kr.com", "huxiu.com", "ifanr.com"
  ]
  
  const lowCredibilityDomains = [
    "blogspot", "wordpress.com", "weibo.com", "twitter.com",
    "facebook.com", "instagram.com", "tiktok.com"
  ]
  
  const lowerHost = hostname.toLowerCase()
  
  if (highCredibilityDomains.some(d => lowerHost.includes(d))) {
    return 0.9
  }
  if (mediumCredibilityDomains.some(d => lowerHost.includes(d))) {
    return 0.7
  }
  if (lowCredibilityDomains.some(d => lowerHost.includes(d))) {
    return 0.4
  }
  
  return 0.6
}

// Stream encoder helper
function encodeSSE(data: object): string {
  return JSON.stringify(data) + "\n"
}

export async function POST(request: NextRequest) {
  const encoder = new TextEncoder()
  
  try {
    const body = await request.json()
    const { query, timeWindow = "7d", tool = "WEB_SEARCH" } = body
    
    if (!query) {
      return new Response(
        JSON.stringify({ error: "Query is required" }),
        { status: 400, headers: { "Content-Type": "application/json" } }
      )
    }
    
    // Create streaming response
    const stream = new ReadableStream({
      async start(controller) {
        try {
          const zai = await ZAI.create()
          
          // Calculate recency days from time window
          const recencyMap: Record<string, number> = {
            "24h": 1,
            "7d": 7,
            "30d": 30,
            "all": 0,
          }
          const recencyDays = recencyMap[timeWindow] || 7
          
          // Build search query with time context
          let searchQuery = query
          if (recencyDays > 0 && tool === "NEWS_SEARCH") {
            searchQuery = `${query} 最新 新闻`
          }
          
          // Send initial progress
          controller.enqueue(encoder(encodeSSE({ type: "progress", progress: 10 })))
          
          // Step 1: Web Search
          const searchArgs: Record<string, unknown> = {
            query: searchQuery,
            num: 15,
          }
          
          if (recencyDays > 0) {
            searchArgs.recency_days = recencyDays
          }
          
          const searchResults = await zai.functions.invoke("web_search", searchArgs)
          
          controller.enqueue(encoder(encodeSSE({ type: "progress", progress: 40 })))
          
          // Process and send sources
          const sources: SearchSource[] = []
          
          if (Array.isArray(searchResults)) {
            for (const result of searchResults) {
              const source: SearchSource = {
                url: result.url || "",
                title: result.name || "Untitled",
                publisher: result.host_name || "",
                snippet: result.snippet || "",
                publishedAt: result.date || undefined,
                credibilityScore: getCredibilityScore(result.host_name || ""),
              }
              sources.push(source)
              
              // Send each source
              controller.enqueue(encoder(encodeSSE({ type: "source", ...source })))
            }
          }
          
          controller.enqueue(encoder(encodeSSE({ type: "progress", progress: 60 })))
          
          // Step 2: Generate Insight using LLM
          const sourceContext = sources
            .slice(0, 8)
            .map((s, i) => `[${i + 1}] ${s.title}\n${s.snippet}`)
            .join("\n\n")
          
          const insightPrompt = `你是一个专业的内容研究助手。基于以下搜索结果，分析并总结选题研究结论。

选题关键词: ${query}

搜索结果:
${sourceContext}

请以 JSON 格式返回以下内容（不要包含其他文字，只返回 JSON）:
{
  "summary": "研究结论摘要（100-200字，总结关键发现和核心观点）",
  "risks": ["风险点1", "风险点2", "风险点3"],
  "angles": ["写作角度1", "写作角度2", "写作角度3", "写作角度4"],
  "recommendedTitles": ["推荐标题1", "推荐标题2", "推荐标题3", "推荐标题4", "推荐标题5"]
}

注意：
1. risks 应包含内容风险、时效性风险、争议点等
2. angles 应提供不同的内容切入角度
3. recommendedTitles 应包含吸引眼球的标题建议`

          const completion = await zai.chat.completions.create({
            messages: [
              {
                role: "assistant",
                content: "你是一个专业的内容研究助手，擅长分析和总结信息。",
              },
              {
                role: "user",
                content: insightPrompt,
              },
            ],
            thinking: { type: "disabled" },
          })
          
          controller.enqueue(encoder(encodeSSE({ type: "progress", progress: 90 })))
          
          const insightText = completion.choices[0]?.message?.content || ""
          
          // Parse insight JSON
          let insight: ResearchInsight = {
            summary: "未能生成研究结论",
            risks: [],
            angles: [],
            recommendedTitles: [],
          }
          
          try {
            // Try to extract JSON from the response
            const jsonMatch = insightText.match(/\{[\s\S]*\}/)
            if (jsonMatch) {
              insight = JSON.parse(jsonMatch[0])
            }
          } catch (e) {
            console.error("Failed to parse insight JSON:", e)
            // Use raw text as summary if parsing fails
            insight.summary = insightText.slice(0, 500)
          }
          
          // Send insight
          controller.enqueue(encoder(encodeSSE({ type: "insight", ...insight })))
          controller.enqueue(encoder(encodeSSE({ type: "progress", progress: 100 })))
          
          controller.close()
        } catch (error) {
          console.error("Research error:", error)
          controller.enqueue(encoder(encodeSSE({
            type: "error",
            message: error instanceof Error ? error.message : "Research failed",
          })))
          controller.close()
        }
      },
    })
    
    return new Response(stream, {
      headers: {
        "Content-Type": "text/event-stream",
        "Cache-Control": "no-cache",
        "Connection": "keep-alive",
      },
    })
  } catch (error) {
    console.error("API error:", error)
    return new Response(
      JSON.stringify({
        error: {
          code: "INTERNAL_ERROR",
          message: "研究请求失败",
          detail: error instanceof Error ? error.message : undefined,
          retryable: true,
        },
      }),
      { status: 500, headers: { "Content-Type": "application/json" } }
    )
  }
}
