import { NextRequest } from "next/server"
import ZAI from "z-ai-web-dev-sdk"

export const runtime = "nodejs"
export const dynamic = "force-dynamic"

// Stream encoder helper
function encodeSSE(data: object): string {
  return JSON.stringify(data) + "\n"
}

export async function POST(request: NextRequest) {
  const encoder = new TextEncoder()
  
  try {
    const body = await request.json()
    const { projectId, tone = "professional", length = "medium" } = body
    
    if (!projectId) {
      return new Response(
        JSON.stringify({ error: "Project ID is required" }),
        { status: 400, headers: { "Content-Type": "application/json" } }
      )
    }
    
    // Create streaming response
    const stream = new ReadableStream({
      async start(controller) {
        try {
          const zai = await ZAI.create()
          
          // Length settings
          const lengthSettings: Record<string, { min: number; max: number }> = {
            short: { min: 500, max: 1000 },
            medium: { min: 1500, max: 2500 },
            long: { min: 3000, max: 5000 },
          }
          
          // Tone settings
          const toneSettings: Record<string, string> = {
            professional: "专业严谨，适合行业分析、技术解读",
            casual: "轻松活泼，适合生活分享、娱乐内容",
            storytelling: "故事叙述，适合情感表达、案例讲述",
            analytical: "分析解读，适合数据报告、趋势分析",
            tutorial: "教程指南，适合操作步骤、技巧分享",
          }
          
          const { min, max } = lengthSettings[length] || lengthSettings.medium
          
          // Build prompt
          const prompt = `你是一位专业的内容创作者。请根据以下选题撰写一篇${toneSettings[tone]}风格的文章。

要求：
1. 字数控制在 ${min}-${max} 字之间
2. 结构清晰，包含标题、导语、正文、结尾
3. 语言流畅，逻辑连贯
4. 适合自媒体平台发布

选题关键词：${projectId}

请直接输出文章内容，不要包含其他说明。`

          // Send initial progress
          controller.enqueue(encoder(encodeSSE({ type: "progress", progress: 10 })))
          
          // Generate content using LLM
          const completion = await zai.chat.completions.create({
            messages: [
              {
                role: "assistant",
                content: "你是一位专业的内容创作者，擅长撰写高质量的文章。请根据用户的要求创作内容。",
              },
              {
                role: "user",
                content: prompt,
              },
            ],
            thinking: { type: "disabled" },
          })
          
          controller.enqueue(encoder(encodeSSE({ type: "progress", progress: 50 })))
          
          const content = completion.choices[0]?.message?.content || ""
          
          // Stream content in chunks
          const chunkSize = 50
          for (let i = 0; i < content.length; i += chunkSize) {
            const chunk = content.slice(i, i + chunkSize)
            controller.enqueue(encoder(encodeSSE({ type: "content", text: chunk })))
            
            // Update progress
            const progress = 50 + Math.floor((i / content.length) * 50)
            controller.enqueue(encoder(encodeSSE({ type: "progress", progress })))
            
            // Small delay for visual effect
            await new Promise(resolve => setTimeout(resolve, 20))
          }
          
          controller.enqueue(encoder(encodeSSE({ type: "progress", progress: 100 })))
          controller.close()
        } catch (error) {
          console.error("Draft generation error:", error)
          controller.enqueue(encoder(encodeSSE({
            type: "error",
            message: error instanceof Error ? error.message : "Generation failed",
          })))
          controller.close()
        }
      },
    })
    
    return new Response(stream, {
      headers: {
        "Content-Type": "text/event-stream",
        "Cache-Control": "no-cache",
        "Connection": "keep-alive",
      },
    })
  } catch (error) {
    console.error("API error:", error)
    return new Response(
      JSON.stringify({
        error: {
          code: "INTERNAL_ERROR",
          message: "生成失败",
          detail: error instanceof Error ? error.message : undefined,
          retryable: true,
        },
      }),
      { status: 500, headers: { "Content-Type": "application/json" } }
    )
  }
}
