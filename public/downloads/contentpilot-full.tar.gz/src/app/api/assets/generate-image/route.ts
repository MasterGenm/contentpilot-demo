import { NextRequest, NextResponse } from "next/server"

export const runtime = "nodejs"
export const dynamic = "force-dynamic"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { projectId, prompt } = body
    
    if (!prompt) {
      return NextResponse.json(
        { error: "Prompt is required" },
        { status: 400 }
      )
    }
    
    // For MVP, return a placeholder image
    // In production, integrate with actual image generation API
    
    const seed = Math.random().toString(36).substring(7)
    
    return NextResponse.json({
      success: true,
      imageUrl: `https://picsum.photos/seed/${seed}/800/600`,
      provider: "placeholder",
      message: "Image generated successfully",
    })
  } catch (error) {
    console.error("Image generation error:", error)
    return NextResponse.json(
      {
        error: {
          code: "INTERNAL_ERROR",
          message: "图片生成失败",
          detail: error instanceof Error ? error.message : undefined,
          retryable: true,
        },
      },
      { status: 500 }
    )
  }
}
