import { NextRequest } from "next/server"
import ZAI from "z-ai-web-dev-sdk"

export const runtime = "nodejs"
export const dynamic = "force-dynamic"

type Platform = "WECHAT" | "XIAOHONGSHU" | "WEIBO" | "BILIBILI"

// Platform-specific configurations
const platformConfigs: Record<Platform, {
  maxLength: number
  style: string
  hashtags: boolean
  titles: boolean
}> = {
  WECHAT: {
    maxLength: 20000,
    style: "专业深度，适合长文阅读",
    hashtags: false,
    titles: true,
  },
  XIAOHONGSHU: {
    maxLength: 1000,
    style: "轻松活泼，注重种草和分享感，多用表情符号",
    hashtags: true,
    titles: true,
  },
  WEIBO: {
    maxLength: 2000,
    style: "简洁有力，适合快速传播",
    hashtags: true,
    titles: false,
  },
  BILIBILI: {
    maxLength: 4000,
    style: "口语化，适合视频口播稿",
    hashtags: true,
    titles: true,
  },
}

function encodeSSE(data: object): string {
  return JSON.stringify(data) + "\n"
}

export async function POST(request: NextRequest) {
  const encoder = new TextEncoder()
  
  try {
    const body = await request.json()
    const { draftId, platforms } = body
    
    if (!draftId || !platforms || !Array.isArray(platforms)) {
      return new Response(
        JSON.stringify({ error: "Draft ID and platforms are required" }),
        { status: 400, headers: { "Content-Type": "application/json" } }
      )
    }
    
    // Create streaming response
    const stream = new ReadableStream({
      async start(controller) {
        try {
          const zai = await ZAI.create()
          
          // Generate for each platform
          for (const platform of platforms as Platform[]) {
            const config = platformConfigs[platform]
            
            // Build prompt for this platform
            const prompt = `你是一位专业的内容运营。请将以下原始内容改写为适合${platform === "WECHAT" ? "微信公众号" : platform === "XIAOHONGSHU" ? "小红书" : platform === "WEIBO" ? "微博" : "B站"}平台的内容。

风格要求：${config.style}
字数上限：${config.maxLength}字

原始内容（摘要）：
${draftId}

请以JSON格式返回：
{
  "titleCandidates": ["标题1", "标题2", "标题3"],
  "body": "改写后的正文内容",
  "hashtags": ${config.hashtags ? '["标签1", "标签2", "标签3"]' : '[]'}
}

只返回JSON，不要包含其他文字。`
            
            try {
              const completion = await zai.chat.completions.create({
                messages: [
                  {
                    role: "assistant",
                    content: "你是一位专业的内容运营，擅长将内容改写为不同平台的风格。",
                  },
                  {
                    role: "user",
                    content: prompt,
                  },
                ],
                thinking: { type: "disabled" },
              })
              
              const response = completion.choices[0]?.message?.content || ""
              
              // Parse JSON response
              let data = {
                titleCandidates: [] as string[],
                body: "",
                hashtags: [] as string[],
              }
              
              try {
                const jsonMatch = response.match(/\{[\s\S]*\}/)
                if (jsonMatch) {
                  data = JSON.parse(jsonMatch[0])
                }
              } catch {
                // Use raw response as body
                data.body = response
              }
              
              // Send variant
              controller.enqueue(encoder(encodeSSE({
                type: "variant",
                platform,
                ...data,
              })))
            } catch (error) {
              console.error(`Failed to generate for ${platform}:`, error)
              controller.enqueue(encoder(encodeSSE({
                type: "error",
                platform,
                message: `生成${platform}版本失败`,
              })))
            }
          }
          
          controller.close()
        } catch (error) {
          console.error("Rewrite error:", error)
          controller.enqueue(encoder(encodeSSE({
            type: "error",
            message: error instanceof Error ? error.message : "Rewrite failed",
          })))
          controller.close()
        }
      },
    })
    
    return new Response(stream, {
      headers: {
        "Content-Type": "text/event-stream",
        "Cache-Control": "no-cache",
        "Connection": "keep-alive",
      },
    })
  } catch (error) {
    console.error("API error:", error)
    return new Response(
      JSON.stringify({
        error: {
          code: "INTERNAL_ERROR",
          message: "改写失败",
          detail: error instanceof Error ? error.message : undefined,
          retryable: true,
        },
      }),
      { status: 500, headers: { "Content-Type": "application/json" } }
    )
  }
}
