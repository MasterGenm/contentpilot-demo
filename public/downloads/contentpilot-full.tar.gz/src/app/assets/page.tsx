"use client"

import * as React from "react"
import {
  Image,
  Wand2,
  Download,
  Loader2,
  Sparkles,
  Copy,
  Plus,
  X,
} from "lucide-react"
import { Header } from "@/components/layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Separator } from "@/components/ui/separator"
import { useStore, type AssetItem, type AssetStatus } from "@/stores/project-store"
import { cn } from "@/lib/utils"
import { toast } from "sonner"

// Mock generated images for display
const placeholderImages = [
  "https://picsum.photos/seed/1/400/300",
  "https://picsum.photos/seed/2/400/300",
  "https://picsum.photos/seed/3/400/300",
]

export default function AssetsPage() {
  const {
    projects,
    currentProjectId,
    assets,
    addAsset,
    updateAsset,
  } = useStore()
  
  // Get current project
  const currentProject = currentProjectId 
    ? projects.find(p => p.id === currentProjectId)
    : projects[0]
  
  // Get project assets
  const projectAssets = currentProject 
    ? assets.filter(a => a.projectId === currentProject.id)
    : []
  
  // State
  const [prompt, setPrompt] = React.useState("")
  const [isGenerating, setIsGenerating] = React.useState(false)
  const [selectedImage, setSelectedImage] = React.useState<string | null>(null)
  
  // Generate image
  const handleGenerate = async () => {
    if (!currentProject) {
      toast.error("请先创建项目")
      return
    }
    
    if (!prompt.trim()) {
      toast.error("请输入图片描述")
      return
    }
    
    setIsGenerating(true)
    
    try {
      // Create asset with pending status
      const assetId = addAsset({
        projectId: currentProject.id,
        prompt,
        status: "GENERATING",
        linkedVariantIds: [],
      })
      
      // Call image generation API
      const response = await fetch("/api/assets/generate-image", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          projectId: currentProject.id,
          prompt,
        }),
      })
      
      if (!response.ok) throw new Error("生成失败")
      
      const data = await response.json()
      
      // Update asset with generated image
      updateAsset(assetId, {
        imageUrl: data.imageUrl,
        provider: data.provider,
        status: "COMPLETED",
      })
      
      setPrompt("")
      toast.success("图片生成完成！")
    } catch (error) {
      console.error("Generate error:", error)
      toast.error("生成失败，请重试")
    } finally {
      setIsGenerating(false)
    }
  }
  
  // Extract prompts from draft (mock function)
  const handleExtractPrompts = () => {
    toast.info("正在从初稿中提取配图提示词...")
    // This would call an API to extract image prompts from the draft
  }
  
  return (
    <div className="flex flex-col min-h-screen">
      <Header title="图文素材">
        <Button variant="outline" size="sm" onClick={handleExtractPrompts}>
          <Sparkles className="size-4 mr-1" />
          提取配图提示词
        </Button>
      </Header>
      
      <main className="flex-1 p-6">
        <div className="grid gap-6 lg:grid-cols-3">
          {/* Left: Generation Panel */}
          <div className="space-y-6">
            {/* Prompt Input */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base">生成配图</CardTitle>
                <CardDescription>描述你想要的图片内容</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="prompt">图片描述</Label>
                  <Input
                    id="prompt"
                    placeholder="例如：一只可爱的猫咪坐在书桌上看电脑..."
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    disabled={isGenerating}
                  />
                </div>
                
                <Button 
                  className="w-full"
                  onClick={handleGenerate}
                  disabled={isGenerating || !prompt.trim()}
                >
                  {isGenerating ? (
                    <Loader2 className="size-4 mr-2 animate-spin" />
                  ) : (
                    <Wand2 className="size-4 mr-2" />
                  )}
                  生成图片
                </Button>
              </CardContent>
            </Card>
            
            {/* Quick Prompts */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm">常用提示词</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {["科技感背景", "简约商务", "温暖自然", "创意插画"].map((text) => (
                    <Button
                      key={text}
                      variant="secondary"
                      size="sm"
                      onClick={() => setPrompt(text)}
                    >
                      {text}
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>
            
            {/* Selected Image */}
            {selectedImage && (
              <Card>
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-sm">已选中</CardTitle>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setSelectedImage(null)}
                    >
                      <X className="size-4" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <img
                    src={selectedImage}
                    alt="Selected"
                    className="w-full rounded-lg"
                  />
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" className="flex-1">
                      <Copy className="size-4 mr-1" />
                      复制链接
                    </Button>
                    <Button size="sm" className="flex-1">
                      <Download className="size-4 mr-1" />
                      下载
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
          
          {/* Right: Asset Gallery */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-base">素材库</CardTitle>
                  <Badge variant="secondary">{projectAssets.length} 张</Badge>
                </div>
              </CardHeader>
              <CardContent>
                {projectAssets.length > 0 ? (
                  <ScrollArea className="h-[500px]">
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                      {projectAssets.map((asset) => (
                        <div
                          key={asset.id}
                          className={cn(
                            "relative group rounded-lg overflow-hidden border cursor-pointer",
                            selectedImage === asset.imageUrl && "ring-2 ring-primary"
                          )}
                          onClick={() => setSelectedImage(asset.imageUrl || null)}
                        >
                          <img
                            src={asset.imageUrl || placeholderImages[0]}
                            alt={asset.prompt}
                            className="w-full aspect-[4/3] object-cover"
                          />
                          
                          {/* Status Badge */}
                          {asset.status === "GENERATING" && (
                            <div className="absolute inset-0 bg-background/80 flex items-center justify-center">
                              <Loader2 className="size-6 animate-spin" />
                            </div>
                          )}
                          
                          {/* Hover Overlay */}
                          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
                            <div className="absolute bottom-0 left-0 right-0 p-2">
                              <p className="text-xs text-white line-clamp-2">
                                {asset.prompt}
                              </p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                ) : (
                  <div className="flex flex-col items-center justify-center py-16 text-center">
                    <Image className="size-12 text-muted-foreground/50 mb-4" />
                    <p className="text-muted-foreground mb-4">还没有素材</p>
                    <p className="text-xs text-muted-foreground">
                      输入提示词生成图片，或从初稿中提取配图建议
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}
