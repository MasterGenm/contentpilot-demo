"use client"

import * as React from "react"
import { useSearchParams } from "next/navigation"
import {
  Search,
  Plus,
  Clock,
  Globe,
  Newspaper,
  Loader2,
  AlertCircle,
  CheckCircle2,
  ExternalLink,
  Sparkles,
  ChevronDown,
  X,
} from "lucide-react"
import { Header } from "@/components/layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Separator } from "@/components/ui/separator"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible"
import { StatusBadge } from "@/components/cards"
import { useStore, type SourceItem, type Insight } from "@/stores/project-store"
import { formatRelativeTime } from "@/lib/date"
import { cn } from "@/lib/utils"
import { toast } from "sonner"

// Time window options
const timeWindowOptions = [
  { value: "24h", label: "最近24小时" },
  { value: "7d", label: "最近一周" },
  { value: "30d", label: "最近30天" },
  { value: "all", label: "不限时间" },
]

export default function ResearchPage() {
  const searchParams = useSearchParams()
  const projectId = searchParams.get("project")
  
  const {
    projects,
    currentProjectId,
    setCurrentProject,
    addProject,
    updateProject,
    researchTasks,
    addResearchTask,
    updateResearchTask,
    sources,
    addSource,
    insights,
    addInsight,
  } = useStore()
  
  // Form state
  const [title, setTitle] = React.useState("")
  const [keywords, setKeywords] = React.useState("")
  const [timeWindow, setTimeWindow] = React.useState("7d")
  const [searchTool, setSearchTool] = React.useState<"WEB_SEARCH" | "NEWS_SEARCH">("WEB_SEARCH")
  
  // Research state
  const [isSearching, setIsSearching] = React.useState(false)
  const [searchProgress, setSearchProgress] = React.useState(0)
  const [currentTaskId, setCurrentTaskId] = React.useState<string | null>(null)
  const [researchResults, setResearchResults] = React.useState<{
    sources: SourceItem[]
    insight: Insight | null
  }>({ sources: [], insight: null })
  
  // Get current project
  const currentProject = projectId 
    ? projects.find(p => p.id === projectId)
    : currentProjectId 
      ? projects.find(p => p.id === currentProjectId)
      : null
  
  // Get project's existing sources and insights
  const projectSources = currentProject 
    ? sources.filter(s => s.projectId === currentProject.id)
    : []
  const projectInsight = currentProject
    ? insights.find(i => i.projectId === currentProject.id)
    : null
  
  // Start research
  const handleStartResearch = async () => {
    if (!keywords.trim()) {
      toast.error("请输入选题关键词")
      return
    }
    
    setIsSearching(true)
    setSearchProgress(0)
    
    try {
      // Create or update project
      let projId = currentProject?.id
      if (!projId) {
        projId = addProject({
          title: title || keywords.split(",").slice(0, 3).join(" - "),
          topicKeywords: keywords.split(",").map(k => k.trim()).filter(Boolean),
          timeWindow,
          status: "RESEARCHING",
        })
        setCurrentProject(projId)
      } else {
        updateProject(projId, { status: "RESEARCHING" })
      }
      
      // Create research task
      const taskId = addResearchTask({
        projectId: projId,
        query: keywords,
        tool: searchTool,
        status: "RUNNING",
        progress: 0,
      })
      setCurrentTaskId(taskId)
      
      // Call research API
      const response = await fetch("/api/research/start", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          query: keywords,
          timeWindow,
          tool: searchTool,
        }),
      })
      
      if (!response.ok) {
        throw new Error("研究请求失败")
      }
      
      const reader = response.body?.getReader()
      if (!reader) throw new Error("无法读取响应")
      
      const decoder = new TextDecoder()
      let accumulatedSources: SourceItem[] = []
      let accumulatedInsight: Insight | null = null
      
      while (true) {
        const { done, value } = await reader.read()
        if (done) break
        
        const chunk = decoder.decode(value)
        const lines = chunk.split("\n").filter(Boolean)
        
        for (const line of lines) {
          try {
            const data = JSON.parse(line)
            
            if (data.type === "progress") {
              setSearchProgress(data.progress)
              updateResearchTask(taskId, { progress: data.progress })
            } else if (data.type === "source") {
              const source: SourceItem = {
                id: `temp-${Date.now()}-${Math.random()}`,
                projectId: projId!,
                url: data.url,
                title: data.title,
                publisher: data.publisher,
                snippet: data.snippet,
                publishedAt: data.publishedAt,
                credibilityScore: data.credibilityScore || 0.5,
                createdAt: new Date().toISOString(),
              }
              accumulatedSources.push(source)
              addSource({
                projectId: projId!,
                url: data.url,
                title: data.title,
                publisher: data.publisher,
                snippet: data.snippet,
                publishedAt: data.publishedAt,
                credibilityScore: data.credibilityScore || 0.5,
              })
            } else if (data.type === "insight") {
              accumulatedInsight = {
                id: `temp-insight-${Date.now()}`,
                projectId: projId!,
                summary: data.summary,
                risks: data.risks || [],
                angles: data.angles || [],
                recommendedTitles: data.recommendedTitles || [],
                createdAt: new Date().toISOString(),
              }
              addInsight({
                projectId: projId!,
                summary: data.summary,
                risks: data.risks || [],
                angles: data.angles || [],
                recommendedTitles: data.recommendedTitles || [],
              })
            }
          } catch (e) {
            // Ignore parse errors for incomplete chunks
          }
        }
        
        setResearchResults({
          sources: accumulatedSources,
          insight: accumulatedInsight,
        })
      }
      
      // Update task as completed
      updateResearchTask(taskId, { 
        status: "COMPLETED", 
        progress: 100,
        endedAt: new Date().toISOString(),
      })
      updateProject(projId, { status: "DRAFTING" })
      
      toast.success("研究完成！")
    } catch (error) {
      console.error("Research error:", error)
      toast.error("研究失败，请重试")
      if (currentTaskId) {
        updateResearchTask(currentTaskId, { 
          status: "FAILED", 
          error: error instanceof Error ? error.message : "未知错误",
        })
      }
    } finally {
      setIsSearching(false)
    }
  }
  
  const displayedSources = researchResults.sources.length > 0 
    ? researchResults.sources 
    : projectSources
  const displayedInsight = researchResults.insight || projectInsight

  return (
    <div className="flex flex-col min-h-screen">
      <Header title="选题研究" />
      
      <main className="flex-1 p-6">
        <div className="grid gap-6 lg:grid-cols-3">
          {/* Left: Input Form */}
          <div className="lg:col-span-1 space-y-6">
            {/* Project Info */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base">研究配置</CardTitle>
                <CardDescription>输入选题关键词开始研究</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="title">项目标题</Label>
                  <Input
                    id="title"
                    placeholder="可选：为项目命名"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    disabled={isSearching}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="keywords">选题关键词 *</Label>
                  <Textarea
                    id="keywords"
                    placeholder="输入关键词，用逗号分隔&#10;例如：AI写作, 内容创作, 自动化"
                    value={keywords}
                    onChange={(e) => setKeywords(e.target.value)}
                    rows={3}
                    disabled={isSearching}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label>时间范围</Label>
                  <Select value={timeWindow} onValueChange={setTimeWindow} disabled={isSearching}>
                    <SelectTrigger>
                      <Clock className="size-4 mr-2" />
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {timeWindowOptions.map((opt) => (
                        <SelectItem key={opt.value} value={opt.value}>
                          {opt.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label>检索源</Label>
                  <div className="grid grid-cols-2 gap-2">
                    <Button
                      variant={searchTool === "WEB_SEARCH" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setSearchTool("WEB_SEARCH")}
                      disabled={isSearching}
                    >
                      <Globe className="size-4 mr-1" />
                      网页搜索
                    </Button>
                    <Button
                      variant={searchTool === "NEWS_SEARCH" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setSearchTool("NEWS_SEARCH")}
                      disabled={isSearching}
                    >
                      <Newspaper className="size-4 mr-1" />
                      新闻搜索
                    </Button>
                  </div>
                </div>
                
                <Separator />
                
                <Button 
                  className="w-full" 
                  onClick={handleStartResearch}
                  disabled={isSearching || !keywords.trim()}
                >
                  {isSearching ? (
                    <>
                      <Loader2 className="size-4 mr-2 animate-spin" />
                      研究中...
                    </>
                  ) : (
                    <>
                      <Search className="size-4 mr-2" />
                      开始研究
                    </>
                  )}
                </Button>
                
                {isSearching && (
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">进度</span>
                      <span className="tabular-nums">{searchProgress}%</span>
                    </div>
                    <Progress value={searchProgress} />
                  </div>
                )}
              </CardContent>
            </Card>
            
            {/* Quick Tips */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Sparkles className="size-4" />
                  研究技巧
                </CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-muted-foreground space-y-2">
                <p>• 使用具体、明确的关键词获得更精准的结果</p>
                <p>• 可以包含行业术语或专业名词</p>
                <p>• 研究完成后可查看证据来源和可信度评分</p>
              </CardContent>
            </Card>
          </div>
          
          {/* Right: Results */}
          <div className="lg:col-span-2 space-y-6">
            {/* Insight Card */}
            {displayedInsight && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-base flex items-center gap-2">
                    <CheckCircle2 className="size-4 text-success" />
                    研究结论
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h4 className="text-sm font-medium mb-2">摘要</h4>
                    <p className="text-sm text-muted-foreground">{displayedInsight.summary}</p>
                  </div>
                  
                  {displayedInsight.recommendedTitles.length > 0 && (
                    <div>
                      <h4 className="text-sm font-medium mb-2">推荐标题</h4>
                      <div className="flex flex-wrap gap-2">
                        {displayedInsight.recommendedTitles.map((title, i) => (
                          <Badge key={i} variant="secondary" className="font-normal">
                            {title}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                  
                  {displayedInsight.angles.length > 0 && (
                    <Collapsible>
                      <CollapsibleTrigger className="flex items-center gap-1 text-sm font-medium hover:text-foreground transition-colors">
                        <ChevronDown className="size-4" />
                        写作角度 ({displayedInsight.angles.length})
                      </CollapsibleTrigger>
                      <CollapsibleContent className="mt-2">
                        <ul className="list-disc list-inside text-sm text-muted-foreground space-y-1">
                          {displayedInsight.angles.map((angle, i) => (
                            <li key={i}>{angle}</li>
                          ))}
                        </ul>
                      </CollapsibleContent>
                    </Collapsible>
                  )}
                  
                  {displayedInsight.risks.length > 0 && (
                    <Collapsible>
                      <CollapsibleTrigger className="flex items-center gap-1 text-sm font-medium hover:text-foreground transition-colors text-warning">
                        <AlertCircle className="size-4" />
                        风险提示 ({displayedInsight.risks.length})
                      </CollapsibleTrigger>
                      <CollapsibleContent className="mt-2">
                        <ul className="list-disc list-inside text-sm text-muted-foreground space-y-1">
                          {displayedInsight.risks.map((risk, i) => (
                            <li key={i}>{risk}</li>
                          ))}
                        </ul>
                      </CollapsibleContent>
                    </Collapsible>
                  )}
                </CardContent>
              </Card>
            )}
            
            {/* Sources List */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-base">
                    证据来源
                    {displayedSources.length > 0 && (
                      <span className="text-muted-foreground font-normal ml-2">
                        ({displayedSources.length})
                      </span>
                    )}
                  </CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                {displayedSources.length > 0 ? (
                  <ScrollArea className="h-[400px] pr-4">
                    <div className="space-y-3">
                      {displayedSources.map((source) => (
                        <div
                          key={source.id}
                          className="p-3 rounded-lg border bg-card hover:bg-muted/50 transition-colors"
                        >
                          <div className="flex items-start justify-between gap-2">
                            <div className="flex-1 min-w-0">
                              <a
                                href={source.url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-sm font-medium hover:underline line-clamp-2"
                              >
                                {source.title}
                              </a>
                              <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground">
                                {source.publisher && (
                                  <span className="font-medium">{source.publisher}</span>
                                )}
                                {source.publishedAt && (
                                  <>
                                    <span>·</span>
                                    <span>{formatRelativeTime(source.publishedAt)}</span>
                                  </>
                                )}
                              </div>
                              {source.snippet && (
                                <p className="text-xs text-muted-foreground mt-2 line-clamp-2">
                                  {source.snippet}
                                </p>
                              )}
                            </div>
                            <div className="flex flex-col items-end gap-2">
                              <a
                                href={source.url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="p-1 hover:bg-muted rounded"
                              >
                                <ExternalLink className="size-4 text-muted-foreground" />
                              </a>
                              <div className={cn(
                                "text-xs px-1.5 py-0.5 rounded",
                                source.credibilityScore >= 0.7 && "bg-success/10 text-success",
                                source.credibilityScore >= 0.4 && source.credibilityScore < 0.7 && "bg-warning/10 text-warning",
                                source.credibilityScore < 0.4 && "bg-destructive/10 text-destructive",
                              )}>
                                可信度 {Math.round(source.credibilityScore * 100)}%
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                ) : (
                  <div className="flex flex-col items-center justify-center py-16 text-center">
                    <Globe className="size-12 text-muted-foreground/50 mb-4" />
                    <p className="text-muted-foreground">输入关键词开始研究</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      研究结果将在这里显示
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}
