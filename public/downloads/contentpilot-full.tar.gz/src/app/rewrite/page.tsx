"use client"

import * as React from "react"
import {
  Layers,
  Wand2,
  Copy,
  Check,
  Loader2,
  FileText,
  MessageSquare,
  AtSign,
  Tv,
} from "lucide-react"
import { Header } from "@/components/layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useStore, type Platform, type PlatformVariant } from "@/stores/project-store"
import { getPlatformConfig, getPlatformColorClass } from "@/lib/platforms"
import { cn } from "@/lib/utils"
import { toast } from "sonner"

const platforms: { id: Platform; icon: typeof FileText; label: string }[] = [
  { id: "WECHAT", icon: FileText, label: "公众号" },
  { id: "XIAOHONGSHU", icon: MessageSquare, label: "小红书" },
  { id: "WEIBO", icon: AtSign, label: "微博" },
  { id: "BILIBILI", icon: Tv, label: "B站" },
]

export default function RewritePage() {
  const {
    projects,
    currentProjectId,
    drafts,
    variants,
    addVariant,
    updateVariant,
  } = useStore()
  
  // Get current project
  const currentProject = currentProjectId 
    ? projects.find(p => p.id === currentProjectId)
    : projects[0]
  
  // Get current draft
  const projectDrafts = currentProject 
    ? drafts.filter(d => d.projectId === currentProject.id)
    : []
  const currentDraft = projectDrafts.find(d => d.isCurrent) || projectDrafts[0]
  
  // Get variants for this draft
  const draftVariants = currentDraft
    ? variants.filter(v => v.draftId === currentDraft.id)
    : []
  
  // State
  const [isGenerating, setIsGenerating] = React.useState(false)
  const [copiedId, setCopiedId] = React.useState<string | null>(null)
  const [activeTab, setActiveTab] = React.useState<Platform>("WECHAT")
  
  // Variant content state
  const [variantContents, setVariantContents] = React.useState<Record<Platform, string>>({
    WECHAT: draftVariants.find(v => v.platform === "WECHAT")?.body || "",
    XIAOHONGSHU: draftVariants.find(v => v.platform === "XIAOHONGSHU")?.body || "",
    WEIBO: draftVariants.find(v => v.platform === "WEIBO")?.body || "",
    BILIBILI: draftVariants.find(v => v.platform === "BILIBILI")?.body || "",
  })
  
  // Update variant contents when draftVariants change
  React.useEffect(() => {
    const newContents = { ...variantContents }
    draftVariants.forEach(v => {
      newContents[v.platform] = v.body
    })
    setVariantContents(newContents)
  }, [draftVariants])
  
  // Generate all variants
  const handleGenerateAll = async () => {
    if (!currentDraft) {
      toast.error("请先创建文章初稿")
      return
    }
    
    setIsGenerating(true)
    
    try {
      const response = await fetch("/api/rewrite/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          draftId: currentDraft.id,
          platforms: platforms.map(p => p.id),
        }),
      })
      
      if (!response.ok) throw new Error("生成失败")
      
      const reader = response.body?.getReader()
      if (!reader) throw new Error("无法读取响应")
      
      const decoder = new TextDecoder()
      
      while (true) {
        const { done, value } = await reader.read()
        if (done) break
        
        const chunk = decoder.decode(value)
        const lines = chunk.split("\n").filter(Boolean)
        
        for (const line of lines) {
          try {
            const data = JSON.parse(line)
            
            if (data.type === "variant") {
              const platform = data.platform as Platform
              
              // Check if variant already exists
              const existingVariant = draftVariants.find(v => v.platform === platform)
              
              if (existingVariant) {
                updateVariant(existingVariant.id, {
                  body: data.body,
                  titleCandidates: data.titleCandidates || [],
                  hashtags: data.hashtags || [],
                })
              } else {
                addVariant({
                  draftId: currentDraft.id,
                  platform,
                  body: data.body,
                  titleCandidates: data.titleCandidates || [],
                  hashtags: data.hashtags || [],
                })
              }
              
              setVariantContents(prev => ({
                ...prev,
                [platform]: data.body,
              }))
            }
          } catch (e) {
            // Ignore parse errors
          }
        }
      }
      
      toast.success("改写完成！")
    } catch (error) {
      console.error("Generate error:", error)
      toast.error("生成失败，请重试")
    } finally {
      setIsGenerating(false)
    }
  }
  
  // Copy to clipboard
  const handleCopy = async (platform: Platform) => {
    const content = variantContents[platform]
    if (!content) return
    
    try {
      await navigator.clipboard.writeText(content)
      setCopiedId(platform)
      toast.success("已复制到剪贴板")
      setTimeout(() => setCopiedId(null), 2000)
    } catch {
      toast.error("复制失败")
    }
  }
  
  // Get variant for platform
  const getVariant = (platform: Platform): PlatformVariant | undefined => {
    return draftVariants.find(v => v.platform === platform)
  }
  
  return (
    <div className="flex flex-col min-h-screen">
      <Header title="多平台改写">
        <Button
          size="sm"
          onClick={handleGenerateAll}
          disabled={isGenerating || !currentDraft}
        >
          {isGenerating ? (
            <Loader2 className="size-4 mr-1 animate-spin" />
          ) : (
            <Wand2 className="size-4 mr-1" />
          )}
          一键改写全部
        </Button>
      </Header>
      
      <main className="flex-1 p-6">
        {!currentDraft ? (
          <div className="flex flex-col items-center justify-center h-full min-h-[400px] text-center">
            <Layers className="size-12 text-muted-foreground/50 mb-4" />
            <p className="text-muted-foreground mb-4">请先创建文章初稿</p>
            <Button variant="outline" onClick={() => window.location.href = "/drafts"}>
              前往初稿编辑
            </Button>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Source Preview */}
            <Card>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm">原始初稿</CardTitle>
                  <Badge variant="secondary">{currentDraft.wordCount} 字</Badge>
                </div>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[120px]">
                  <p className="text-sm text-muted-foreground whitespace-pre-wrap">
                    {currentDraft.contentMd.slice(0, 500)}...
                  </p>
                </ScrollArea>
              </CardContent>
            </Card>
            
            {/* Platform Tabs */}
            <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as Platform)}>
              <TabsList className="grid w-full grid-cols-4">
                {platforms.map((platform) => (
                  <TabsTrigger 
                    key={platform.id} 
                    value={platform.id}
                    className="flex items-center gap-2"
                  >
                    <platform.icon className="size-4" />
                    {platform.label}
                  </TabsTrigger>
                ))}
              </TabsList>
              
              {platforms.map((platform) => {
                const config = getPlatformConfig(platform.id)
                const variant = getVariant(platform.id)
                const content = variantContents[platform.id]
                
                return (
                  <TabsContent key={platform.id} value={platform.id} className="mt-4">
                    <Card>
                      <CardHeader className="pb-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <div className={cn(
                              "size-3 rounded-full",
                              getPlatformColorClass(platform.id).split(" ")[1]
                            )} />
                            <CardTitle className="text-sm">{config.name}</CardTitle>
                          </div>
                          <div className="flex items-center gap-2">
                            {content && (
                              <>
                                <span className="text-xs text-muted-foreground tabular-nums">
                                  {content.length} 字
                                </span>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => handleCopy(platform.id)}
                                >
                                  {copiedId === platform.id ? (
                                    <Check className="size-4 text-success" />
                                  ) : (
                                    <Copy className="size-4" />
                                  )}
                                </Button>
                              </>
                            )}
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        {/* Title Candidates */}
                        {variant?.titleCandidates && variant.titleCandidates.length > 0 && (
                          <div>
                            <p className="text-xs font-medium mb-2">标题候选</p>
                            <div className="space-y-1">
                              {variant.titleCandidates.map((title, i) => (
                                <p key={i} className="text-sm font-medium">{title}</p>
                              ))}
                            </div>
                          </div>
                        )}
                        
                        {/* Body */}
                        <div>
                          <p className="text-xs font-medium mb-2">正文</p>
                          <Textarea
                            value={content}
                            onChange={(e) => {
                              setVariantContents(prev => ({
                                ...prev,
                                [platform.id]: e.target.value,
                              }))
                              if (variant) {
                                updateVariant(variant.id, { body: e.target.value })
                              }
                            }}
                            placeholder="改写内容将在这里显示..."
                            className="min-h-[300px] text-sm"
                            disabled={isGenerating}
                          />
                        </div>
                        
                        {/* Hashtags */}
                        {config.features.hashtags && variant?.hashtags && variant.hashtags.length > 0 && (
                          <div>
                            <p className="text-xs font-medium mb-2">话题标签</p>
                            <div className="flex flex-wrap gap-1">
                              {variant.hashtags.map((tag, i) => (
                                <Badge key={i} variant="secondary" className="font-normal">
                                  #{tag}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        )}
                        
                        {/* Platform Guidelines */}
                        <div className="pt-2 border-t">
                          <p className="text-xs text-muted-foreground">
                            {config.name} · 字数上限 {config.maxLength} · 标题上限 {config.titleMaxLength}
                          </p>
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>
                )
              })}
            </Tabs>
          </div>
        )}
      </main>
    </div>
  )
}
