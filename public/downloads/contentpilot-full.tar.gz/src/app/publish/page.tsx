"use client"

import * as React from "react"
import {
  Send,
  Download,
  Loader2,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  ExternalLink,
  FileText,
  Archive,
  Wordpress,
} from "lucide-react"
import { Header } from "@/components/layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Separator } from "@/components/ui/separator"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { useStore, type PublishTarget, type TaskStatus } from "@/stores/project-store"
import { formatRelativeTime, formatDateTime } from "@/lib/date"
import { cn } from "@/lib/utils"
import { toast } from "sonner"

const exportFormats: { value: PublishTarget; label: string; icon: typeof FileText }[] = [
  { value: "EXPORT_MD", label: "Markdown", icon: FileText },
  { value: "EXPORT_HTML", label: "HTML", icon: FileText },
  { value: "EXPORT_JSON", label: "JSON", icon: FileText },
  { value: "EXPORT_ZIP", label: "ZIP 打包", icon: Archive },
]

export default function PublishPage() {
  const {
    projects,
    currentProjectId,
    drafts,
    variants,
    publishJobs,
    addPublishJob,
    updatePublishJob,
  } = useStore()
  
  // Get current project
  const currentProject = currentProjectId 
    ? projects.find(p => p.id === currentProjectId)
    : projects[0]
  
  // Get current draft and variants
  const projectDrafts = currentProject 
    ? drafts.filter(d => d.projectId === currentProject.id)
    : []
  const currentDraft = projectDrafts.find(d => d.isCurrent) || projectDrafts[0]
  
  const draftVariants = currentDraft
    ? variants.filter(v => v.draftId === currentDraft.id)
    : []
  
  // State
  const [selectedVariant, setSelectedVariant] = React.useState<string>("")
  const [isExporting, setIsExporting] = React.useState(false)
  const [isPublishing, setIsPublishing] = React.useState(false)
  
  // Get project publish jobs
  const projectPublishJobs = currentProject
    ? publishJobs.filter(j => j.projectId === currentProject.id)
    : []
  
  // Export handler
  const handleExport = async (format: PublishTarget) => {
    if (!currentDraft) {
      toast.error("没有可导出的内容")
      return
    }
    
    setIsExporting(true)
    
    try {
      const response = await fetch("/api/export/package", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          projectId: currentProject?.id,
          variantId: selectedVariant || undefined,
          format,
        }),
      })
      
      if (!response.ok) throw new Error("导出失败")
      
      // Create download
      const blob = await response.blob()
      const url = URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = `contentpilot-export-${Date.now()}.${format.split("_")[1].toLowerCase()}`
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(url)
      
      // Record publish job
      addPublishJob({
        projectId: currentProject!.id,
        variantId: selectedVariant || undefined,
        target: format,
        status: "COMPLETED",
        retryCount: 0,
      })
      
      toast.success("导出成功！")
    } catch (error) {
      console.error("Export error:", error)
      toast.error("导出失败，请重试")
    } finally {
      setIsExporting(false)
    }
  }
  
  // WordPress publish handler
  const handleWordPressPublish = async () => {
    if (!currentDraft || !selectedVariant) {
      toast.error("请选择要发布的平台版本")
      return
    }
    
    setIsPublishing(true)
    
    // Create pending job
    const jobId = addPublishJob({
      projectId: currentProject!.id,
      variantId: selectedVariant,
      target: "WORDPRESS",
      status: "PENDING",
      retryCount: 0,
    })
    
    try {
      const response = await fetch("/api/publish/wordpress-draft", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          variantId: selectedVariant,
        }),
      })
      
      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.message || "发布失败")
      }
      
      const data = await response.json()
      
      updatePublishJob(jobId, {
        status: "COMPLETED",
        remotePostId: data.postId,
      })
      
      toast.success("已推送至 WordPress 草稿！")
    } catch (error) {
      console.error("Publish error:", error)
      updatePublishJob(jobId, {
        status: "FAILED",
        lastError: error instanceof Error ? error.message : "未知错误",
      })
      toast.error("发布失败，请重试")
    } finally {
      setIsPublishing(false)
    }
  }
  
  // Retry failed job
  const handleRetry = (jobId: string) => {
    updatePublishJob(jobId, { status: "PENDING", retryCount: 0 })
    toast.info("正在重试...")
  }
  
  return (
    <div className="flex flex-col min-h-screen">
      <Header title="发布与归档" />
      
      <main className="flex-1 p-6">
        <div className="grid gap-6 lg:grid-cols-3">
          {/* Left: Publish Panel */}
          <div className="space-y-6">
            {/* Variant Selection */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base">选择版本</CardTitle>
                <CardDescription>选择要发布的平台版本</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Select value={selectedVariant} onValueChange={setSelectedVariant}>
                  <SelectTrigger>
                    <SelectValue placeholder="选择平台版本" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="draft-original">
                      原始初稿
                    </SelectItem>
                    {draftVariants.map((variant) => (
                      <SelectItem key={variant.id} value={variant.id}>
                        {variant.platform === "WECHAT" && "公众号"}
                        {variant.platform === "XIAOHONGSHU" && "小红书"}
                        {variant.platform === "WEIBO" && "微博"}
                        {variant.platform === "BILIBILI" && "B站"}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                
                <Separator />
                
                {/* WordPress Publish */}
                <div className="space-y-2">
                  <p className="text-sm font-medium">推送发布</p>
                  <Button
                    className="w-full"
                    onClick={handleWordPressPublish}
                    disabled={isPublishing || !selectedVariant}
                  >
                    {isPublishing ? (
                      <Loader2 className="size-4 mr-2 animate-spin" />
                    ) : (
                      <Wordpress className="size-4 mr-2" />
                    )}
                    推送至 WordPress 草稿
                  </Button>
                </div>
              </CardContent>
            </Card>
            
            {/* Export Options */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base">导出发布包</CardTitle>
                <CardDescription>导出内容文件</CardDescription>
              </CardHeader>
              <CardContent className="space-y-2">
                {exportFormats.map((format) => (
                  <Button
                    key={format.value}
                    variant="outline"
                    className="w-full justify-start"
                    onClick={() => handleExport(format.value)}
                    disabled={isExporting || !currentDraft}
                  >
                    <format.icon className="size-4 mr-2" />
                    {format.label}
                    <Download className="size-4 ml-auto" />
                  </Button>
                ))}
              </CardContent>
            </Card>
          </div>
          
          {/* Right: Job History */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-base">发布记录</CardTitle>
                  <Badge variant="secondary">{projectPublishJobs.length} 条</Badge>
                </div>
              </CardHeader>
              <CardContent>
                {projectPublishJobs.length > 0 ? (
                  <ScrollArea className="h-[400px]">
                    <div className="space-y-3">
                      {projectPublishJobs.map((job) => (
                        <div
                          key={job.id}
                          className="p-3 rounded-lg border bg-card"
                        >
                          <div className="flex items-start justify-between">
                            <div className="space-y-1">
                              <div className="flex items-center gap-2">
                                <span className="font-medium text-sm">
                                  {job.target === "WORDPRESS" && "WordPress"}
                                  {job.target === "EXPORT_MD" && "Markdown 导出"}
                                  {job.target === "EXPORT_HTML" && "HTML 导出"}
                                  {job.target === "EXPORT_JSON" && "JSON 导出"}
                                  {job.target === "EXPORT_ZIP" && "ZIP 打包"}
                                </span>
                                <StatusBadge status={job.status} />
                              </div>
                              <p className="text-xs text-muted-foreground">
                                {formatDateTime(job.createdAt)}
                              </p>
                              {job.lastError && (
                                <p className="text-xs text-destructive mt-1">
                                  错误: {job.lastError}
                                </p>
                              )}
                              {job.remotePostId && (
                                <p className="text-xs text-success mt-1">
                                  文章 ID: {job.remotePostId}
                                </p>
                              )}
                            </div>
                            
                            <div className="flex items-center gap-2">
                              {job.status === "FAILED" && (
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => handleRetry(job.id)}
                                >
                                  <RefreshCw className="size-4" />
                                </Button>
                              )}
                              {job.status === "COMPLETED" && job.remotePostId && (
                                <Button variant="ghost" size="sm">
                                  <ExternalLink className="size-4" />
                                </Button>
                              )}
                            </div>
                          </div>
                          
                          {job.retryCount > 0 && (
                            <p className="text-xs text-muted-foreground mt-2">
                              重试次数: {job.retryCount}
                            </p>
                          )}
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                ) : (
                  <div className="flex flex-col items-center justify-center py-16 text-center">
                    <Send className="size-12 text-muted-foreground/50 mb-4" />
                    <p className="text-muted-foreground mb-4">还没有发布记录</p>
                    <p className="text-xs text-muted-foreground">
                      选择版本后点击发布或导出
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}

// Status badge component
function StatusBadge({ status }: { status: TaskStatus }) {
  const config: Record<TaskStatus, { label: string; icon: typeof CheckCircle2; className: string }> = {
    PENDING: { label: "等待中", icon: Loader2, className: "text-muted-foreground" },
    RUNNING: { label: "进行中", icon: Loader2, className: "text-primary" },
    COMPLETED: { label: "已完成", icon: CheckCircle2, className: "text-success" },
    FAILED: { label: "失败", icon: AlertCircle, className: "text-destructive" },
    CANCELLED: { label: "已取消", icon: AlertCircle, className: "text-muted-foreground" },
  }
  
  const { label, icon: Icon, className } = config[status]
  
  return (
    <Badge variant="secondary" className={cn("font-normal", className)}>
      <Icon className={cn("size-3 mr-1", status === "RUNNING" && "animate-spin")} />
      {label}
    </Badge>
  )
}
