// API Response Types
export interface ApiResponse<T = unknown> {
  success: boolean
  data?: T
  error?: ApiError
}

export interface ApiError {
  code: string
  message: string
  detail?: string
  retryable: boolean
}

// Error codes
export const ErrorCodes = {
  UPSTREAM_TIMEOUT: "UPSTREAM_TIMEOUT",
  INVALID_INPUT: "INVALID_INPUT",
  PUBLISH_AUTH_FAILED: "PUBLISH_AUTH_FAILED",
  NOT_FOUND: "NOT_FOUND",
  RATE_LIMITED: "RATE_LIMITED",
  INTERNAL_ERROR: "INTERNAL_ERROR",
} as const

// Helper to create API errors
export function createError(
  code: keyof typeof ErrorCodes,
  message: string,
  detail?: string,
  retryable = false
): ApiError {
  return { code, message, detail, retryable }
}

// API client helpers
export async function apiFetch<T>(
  url: string,
  options?: RequestInit
): Promise<ApiResponse<T>> {
  try {
    const response = await fetch(url, {
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...options?.headers,
      },
    })

    const data = await response.json()

    if (!response.ok) {
      return {
        success: false,
        error: data.error || createError(
          "INTERNAL_ERROR",
          "请求失败",
          undefined,
          response.status >= 500
        ),
      }
    }

    return { success: true, data }
  } catch (e) {
    return {
      success: false,
      error: createError(
        "INTERNAL_ERROR",
        "网络请求失败",
        e instanceof Error ? e.message : undefined,
        true
      ),
    }
  }
}

// POST helper
export async function apiPost<T>(url: string, body: unknown): Promise<ApiResponse<T>> {
  return apiFetch<T>(url, {
    method: "POST",
    body: JSON.stringify(body),
  })
}

// GET helper
export async function apiGet<T>(url: string): Promise<ApiResponse<T>> {
  return apiFetch<T>(url, { method: "GET" })
}
